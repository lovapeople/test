(function () {
  // scroll-aware nav
  var nav = document.querySelector('.nav');
  var hasHero = document.body.hasAttribute('data-hero');
  function onScroll() {
    if (!nav) return;
    var solid = window.scrollY > (hasHero ? window.innerHeight * 0.7 : 20);
    nav.classList.toggle('nav--solid', solid);
    nav.classList.toggle('nav--top', !solid && hasHero);
  }
  if (!hasHero && nav) { nav.classList.add('nav--solid'); }
  onScroll();
  window.addEventListener('scroll', onScroll, { passive: true });

  // reveal on scroll
  var io = new IntersectionObserver(function (entries) {
    entries.forEach(function (e) {
      if (e.isIntersecting) { e.target.classList.add('in'); io.unobserve(e.target); }
    });
  }, { threshold: 0.12, rootMargin: '0px 0px -8% 0px' });
  document.querySelectorAll('.reveal').forEach(function (el, i) {
    el.style.transitionDelay = ((i % 4) * 90) + 'ms';
    io.observe(el);
  });

  // count up stats
  var so = new IntersectionObserver(function (entries) {
    entries.forEach(function (e) {
      if (!e.isIntersecting) return;
      var el = e.target, target = parseFloat(el.dataset.count), suffix = el.dataset.suffix || '';
      var dur = 1400, t0 = performance.now();
      function tick(now) {
        var p = Math.min((now - t0) / dur, 1);
        var v = target * (1 - Math.pow(1 - p, 3));
        el.textContent = (target % 1 ? v.toFixed(1) : Math.round(v).toLocaleString()) + suffix;
        if (p < 1) requestAnimationFrame(tick);
      }
      requestAnimationFrame(tick);
      so.unobserve(el);
    });
  }, { threshold: 0.5 });
  document.querySelectorAll('[data-count]').forEach(function (el) { so.observe(el); });

  // mobile menu
  var btn = document.querySelector('[data-menu-toggle]');
  var menu = document.querySelector('[data-menu]');
  if (btn && menu) {
    btn.addEventListener('click', function () {
      var open = menu.classList.toggle('hidden') === false;
      document.body.style.overflow = open ? 'hidden' : '';
    });
    menu.querySelectorAll('a').forEach(function (a) {
      a.addEventListener('click', function () { menu.classList.add('hidden'); document.body.style.overflow = ''; });
    });
  }
})();
